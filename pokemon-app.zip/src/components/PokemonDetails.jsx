import React from 'react';
import { useParams } from 'react-router-dom';
import useFetch from '../hooks/useFetch';

function PokemonDetails() {
  const { name } = useParams();
  const { data: pokemon, loading } = useFetch(`https://pokeapi.co/api/v2/pokemon/${name}`);

  if (loading) return <p>Carregando detalhes do Pokémon...</p>;

  return (
    <div>
      <h1>Detalhes de {pokemon.name}</h1>
      <img src={pokemon.sprites.front_default} alt={pokemon.name} />
      <p>Altura: {pokemon.height}</p>
      <p>Peso: {pokemon.weight}</p>
      <p>Habilidades:</p>
      <ul>
        {pokemon.abilities.map((ability, index) => (
          <li key={index}>{ability.ability.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default PokemonDetails;
