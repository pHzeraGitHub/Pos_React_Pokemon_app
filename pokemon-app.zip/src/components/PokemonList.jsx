// src/components/PokemonList.jsx
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import useFetch from '../hooks/useFetch';

const PokemonList = () => {
  const { data: pokemons, loading, error } = useFetch('https://pokeapi.co/api/v2/pokemon?limit=20');
  const [pokemonDetails, setPokemonDetails] = useState([]);

  // Função para buscar detalhes dos Pokémons
  useEffect(() => {
    const fetchPokemonDetails = async () => {
      if (pokemons?.results) {
        const detailsPromises = pokemons.results.map(async (pokemon) => {
          const response = await fetch(pokemon.url); // Usando a URL já fornecida para buscar detalhes
          return response.json();
        });

        const details = await Promise.all(detailsPromises);
        setPokemonDetails(details);
      }
    };

    fetchPokemonDetails();
  }, [pokemons]);

  if (loading) return <p>Carregando Pokémons...</p>;
  if (error) return <p>Erro ao carregar Pokémons: {error}</p>;

  return (
    <div style={styles.container}>
      <ul style={styles.list}>
        {pokemonDetails.map((pokemon, index) => (
          <li key={index} style={styles.listItem}>
            <Link to={`/pokemon/${pokemon.name}`} style={styles.link}>
              <img src={pokemon.sprites.front_default} alt={pokemon.name} style={styles.image} />
              <p>{pokemon.name}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

// Estilos em JavaScript (inline)
const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh', // Centraliza verticalmente
  },
  list: {
    listStyleType: 'none', // Remove bullets
    padding: 0,
    margin: 0,
  },
  listItem: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '10px', // Espaço entre os itens
    padding: '10px',
    border: '1px solid #ddd',
    borderRadius: '8px',
    width: '250px', // Largura fixa dos itens
    backgroundColor: '#f9f9f9',
  },
  link: {
    textDecoration: 'none',
    color: 'black',
    display: 'flex',
    alignItems: 'center',
    width: '100%',
  },
  image: {
    marginRight: '10px', // Espaço entre imagem e nome
    width: '50px',
    height: '50px',
  },
};

export default PokemonList;
